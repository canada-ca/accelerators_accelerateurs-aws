import boto3
import collections
import datetime
import sys
import pprint
import time
import json
import os

ec2_client = boto3.client('ec2')
cf_client = boto3.client('cloudformation')

def lambda_handler(event, context):
    
    transit_gateway_id = os.environ['transitGatewayId']
    
    stacks = cf_client.describe_stacks(
        StackName="GC-AWS-Accelerator-UTM-Firewall-VPC"
    ).get('Stacks', [])
    
    if stacks[0]['StackStatus'] != "CREATE_COMPLETE":
        return {"status": "Not Finished"}
            
    transit_gateway_attachments = ec2_client.describe_transit_gateway_attachments(
                Filters = [
                    {
                        'Name': 'transit-gateway-id',
                        'Values': [
                            transit_gateway_id
                        ]
                    }
                ]
    ).get('TransitGatewayAttachments', [])
    
    tgw_route_tables = ec2_client.describe_transit_gateway_route_tables(
                Filters = [
                    {
                        'Name': 'tag:Name',
                        'Values': [
                            'UTM Firewall VPC Transit Gateway Route Table'
                        ]
                    }
                ]
    ).get('TransitGatewayRouteTables', [])    
    
    
    transit_gateway_network_security_vpc_route_table_id = tgw_route_tables[0]['TransitGatewayRouteTableId']
    
    for attachment in transit_gateway_attachments:
        if attachment['State'] == 'available':
            attachment_id = attachment['TransitGatewayAttachmentId']
            response = ec2_client.enable_transit_gateway_route_table_propagation(
                TransitGatewayRouteTableId=transit_gateway_network_security_vpc_route_table_id,
                TransitGatewayAttachmentId=attachment_id
            )
    
    
    route_tables = ec2_client.describe_route_tables(
                                Filters = [
                                    {
                                        'Name': 'tag:Name',
                                        'Values': [
                                            'Firewall Trust Interface Subnet Route Table'
                                        ]
                                    }
                                ]).get('RouteTables', [])
                                
    firewall_trust_route_table_id = route_tables[0]['RouteTableId']

    response = ec2_client.create_route(
        DestinationCidrBlock='0.0.0.0/0',
        TransitGatewayId = transit_gateway_id,
        RouteTableId=firewall_trust_route_table_id
    )
    
    return {"status": "Finished"}
    
