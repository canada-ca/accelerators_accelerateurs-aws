import boto3
import collections
import datetime
import sys
import pprint
import time
import json
import os

ec2_client = boto3.client('ec2')
s3_client = boto3.client('s3')
cf_client = boto3.client('cloudformation')
s3 = boto3.resource('s3')

def lambda_handler(event, context):
    
    templates_bucket_name = os.environ['templatesBucketName']
    templates_bucket_path = os.environ['templatesBucketPath']
    vpc_cidr = os.environ['networkSecurityVpcCidr']
    firewall_management_interface_cidr = os.environ['firewallManagementInterfaceSubnetCidr']
    firewall_untrust_interface_cidr = os.environ['firewallUntrustInterfaceSubnetCidr']
    firewall_trust_interface_cidr = os.environ['firewallTrustInterfaceSubnetCidr']
    firewall_management_gateway_cidr = os.environ['firewallManagementGatewaySubnetCidr']
    transit_gateway_attachment_cidr = os.environ['transitGatewayAttachmentSubnetCidr']
    management_traffic_source_cidr = os.environ['managementTrafficSourceCidr']
    utm_firewall_AMI_id = os.environ['utmFirewallAMIId']
    utm_firewall_management_bastion_AMI_id = os.environ['firewallManagementBastionAMIId']
    aws_key_pair_name = os.environ['awsKeyPairName']
    transit_gateway_id = os.environ['transitGatewayId']
    
    s3_object_url_prefix = 'https://s3.amazonaws.com/'+templates_bucket_name+'/'+templates_bucket_path+'network/'
    
    network_restore_object_name = 'utm_firewall_vpc.json'
    
    network_restore_template_url = s3_object_url_prefix+network_restore_object_name
    
    
    response = ec2_client.describe_transit_gateway_route_tables(
            Filters = [
                {
                    'Name': 'default-association-route-table',
                    'Values': [
                        'true'
                    ]
                }
            ]
    )
    
    default_association_route_table_id = response['TransitGatewayRouteTables'][0]['TransitGatewayRouteTableId']
    
    
    parameters = []

    parameters.append({'ParameterKey':  "TemplatesS3BucketName", 'ParameterValue': templates_bucket_name})
    parameters.append({'ParameterKey':  "TemplatesS3BucketPath", 'ParameterValue': templates_bucket_path}) 
    parameters.append({'ParameterKey':  "networkSecurityVpcCidr", 'ParameterValue': vpc_cidr}) 
    parameters.append({'ParameterKey':  "firewallManagementInterfaceSubnetCidr", 'ParameterValue': firewall_management_interface_cidr })
    parameters.append({'ParameterKey':  "firewallUntrustInterfaceSubnetCidr", 'ParameterValue': firewall_untrust_interface_cidr})
    parameters.append({'ParameterKey':  "firewallTrustInterfaceSubnetCidr", 'ParameterValue': firewall_trust_interface_cidr}) 
    parameters.append({'ParameterKey':  "firewallManagementGatewaySubnetCidr", 'ParameterValue': firewall_management_gateway_cidr}) 
    parameters.append({'ParameterKey':  "transitGatewayAttachmentSubnetCidr", 'ParameterValue': transit_gateway_attachment_cidr}) 
    parameters.append({'ParameterKey':  "managementTrafficSourceCidr", 'ParameterValue': management_traffic_source_cidr})
    parameters.append({'ParameterKey':  "utmFirewallAMIId", 'ParameterValue': utm_firewall_AMI_id})
    parameters.append({'ParameterKey':  "firewallManagementBastionAMIId", 'ParameterValue': utm_firewall_management_bastion_AMI_id})        
    parameters.append({'ParameterKey':  "awsKeyPairName", 'ParameterValue': aws_key_pair_name})
    parameters.append({'ParameterKey':  "transitGatewayId", 'ParameterValue': transit_gateway_id})
    parameters.append({'ParameterKey':  "defaultAssociationRouteTableId", 'ParameterValue': default_association_route_table_id})
    
    response = cf_client.create_stack(
        StackName='GC-AWS-Accelerator-UTM-Firewall-VPC',
        Parameters=parameters,
        TemplateURL = network_restore_template_url,
        EnableTerminationProtection = True
    )
        